﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skolor
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
            cbxKommuner.Items.Insert(1,"Lund");
            cbxKommuner.Items.Insert(2,"Malmö");
            cbxKommuner.Items.Add("Skurup");
            cbxProgram.Items.Add("Teknik");
            cbxProgram.Items.Add("Samhäll");
            cbxProgram.Items.Add("Ekonomi");
            cbxProgram.Items.Add("Natur");
            cbxProgram.Items.Add("Fordon & Transport");
            cbxProgram.Items.Add("Bygg & Anläggning");
            cbxProgram.Items.Add("El & Energi");
            cbxSkolor.Items.Add("Polhemskolan");
            cbxSkolor.Items.Add("Katedralskolan");
            cbxSkolor.Items.Add("ProCivitas");
            cbxSkolor.Items.Add("Gymnasieskolan Vipan");
            cbxSkolor.Items.Add("Borgarskolan");
            cbxSkolor.Items.Add("Pauliskolan");
            cbxSkolor.Items.Add("S:t Petriskolan");
            cbxSkolor.Items.Add("Nils Holgerssongymnasiet");

            /*using (var context = new SkolorDBEntities1()) {
                foreach (Skola skola in context.Skolor) {
                    cbxSkolor.Items.Add(skola.Namn);
                
                }

                foreach (Program program in context.Program) {
                    cbxProgram.Items.Add(program.Namn);
                
                }

                foreach (Kommun kommun in context.Kommuner) {
                    cbxKommuner.Items.Add(kommun.Namn);
                }

            }*/


        }

        private void btnSök_Click(object sender, EventArgs e)
        {
            string namn = tbxNamn.Text;
            int merit = int.Parse(tbxMerit.Text);
            string PersonNr = tbxPersonNr.Text;

            using (var context = new SkolorDBEntities1())
            {
                foreach (Skolor_Program temp in context.Skolor_Program) {


                    if (merit >= int.Parse(temp.Intagningspoäng))
                    {
                        rbxLista.Text += SkolidtoNamn(temp.Skolid) + " " + temp.Program + " " + temp.Intagningspoäng;
                    }

                
                }
            }         
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public string SkolidtoNamn(int id)
        {
            using (var context = new SkolorDBEntities1())
            {
                var skola = from s in context.Skolor
                            where s.Skolid == id
                            select new { s.Namn };
                return skola.First().Namn;
            }        
        
        }

    }
}
