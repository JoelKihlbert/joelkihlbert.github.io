﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Form1 : Form
    {
        private SkolDBEntities context = new SkolDBEntities();

        public Form1()
        {
            InitializeComponent();
            
          

            cbxSkolor.DisplayMember = "Namn";
   
            cbxProgram.DisplayMember = "Namn";

            foreach (Kommun kommun in context.Kommuner)
            {
                cbxKommuner.Items.Add(kommun);
            }

            cbxKommuner.DisplayMember = "Namn";

        }

        private void btnSök_Click(object sender, EventArgs e)
        {
            string namn = tbxNamn.Text;
            int merit = int.Parse(tbxMerit.Text);
            string Personnr = tbxPersonNr.Text;



            foreach (Elev temp in context.Elever)
            {
                if (temp.PersonNr != Personnr)
                {
                    MessageBox.Show("Du är inte registrerad", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            foreach (Skola_Kurs temp in context.Skolor_Kurser)
            {
                if (merit >= int.Parse(temp.Intagningspoäng))
                {
                    rbxLista.Text += (temp.Skolid) + " " + temp.Kurskod + " " + temp.Intagningspoäng;
                }
            }
        }

             public string SkolidtoNamn(int id)
        {

            
                var skola = from s in context.Skolor
                            where s.Skolid == id
                            select new { s.Namn };
                return skola.First().Namn;
                   
        
        }

             private void cbxVisaAlla_CheckedChanged(object sender, EventArgs e)
             {
                 foreach (Skola_Kurs temp in context.Skolor_Kurser)
                 {
                     if (cbxVisaAlla.Checked)
                     {
                         rbxLista.Text += (temp.Skolid) + " " + temp.Kurskod + " " + temp.Intagningspoäng;
                     }
                 }
             }

        private void btnVälj_Click(object sender, EventArgs e)
        {

        }

        private void cbxKommuner_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query = from s in context.Skolor
                        where s.Kommun == cbxKommuner.Text
                        select s;
            foreach (var skola in query )
            {
                cbxSkolor.Items.Add(skola);
            }
        }

        private void cbxSkolor_SelectedIndexChanged(object sender, EventArgs e)
        {
            var query = from k in context.Kurser
                        where
        }
    }
    }

