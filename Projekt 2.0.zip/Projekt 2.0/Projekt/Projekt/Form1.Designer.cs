﻿namespace Projekt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExempel = new System.Windows.Forms.Label();
            this.btnVälj = new System.Windows.Forms.Button();
            this.cbxVisaAlla = new System.Windows.Forms.CheckBox();
            this.lblFilter = new System.Windows.Forms.Label();
            this.cbxProgram = new System.Windows.Forms.ComboBox();
            this.cbxSkolor = new System.Windows.Forms.ComboBox();
            this.cbxKommuner = new System.Windows.Forms.ComboBox();
            this.lblPersonNr = new System.Windows.Forms.Label();
            this.tbxPersonNr = new System.Windows.Forms.TextBox();
            this.tbxMerit = new System.Windows.Forms.TextBox();
            this.lblMerit = new System.Windows.Forms.Label();
            this.lblNamn = new System.Windows.Forms.Label();
            this.rbxLista = new System.Windows.Forms.RichTextBox();
            this.tbxNamn = new System.Windows.Forms.TextBox();
            this.btnSök = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblExempel
            // 
            this.lblExempel.AutoSize = true;
            this.lblExempel.Location = new System.Drawing.Point(277, 5);
            this.lblExempel.Name = "lblExempel";
            this.lblExempel.Size = new System.Drawing.Size(86, 13);
            this.lblExempel.TabIndex = 32;
            this.lblExempel.Text = "ÅÅMMDD-XXXX";
            // 
            // btnVälj
            // 
            this.btnVälj.Location = new System.Drawing.Point(181, 435);
            this.btnVälj.Name = "btnVälj";
            this.btnVälj.Size = new System.Drawing.Size(54, 21);
            this.btnVälj.TabIndex = 31;
            this.btnVälj.Text = "Välj";
            this.btnVälj.UseVisualStyleBackColor = true;
            // 
            // cbxVisaAlla
            // 
            this.cbxVisaAlla.AutoSize = true;
            this.cbxVisaAlla.Location = new System.Drawing.Point(280, 200);
            this.cbxVisaAlla.Name = "cbxVisaAlla";
            this.cbxVisaAlla.Size = new System.Drawing.Size(65, 17);
            this.cbxVisaAlla.TabIndex = 30;
            this.cbxVisaAlla.Text = "Visa alla";
            this.cbxVisaAlla.UseVisualStyleBackColor = true;
            this.cbxVisaAlla.CheckedChanged += new System.EventHandler(this.cbxVisaAlla_CheckedChanged);
            // 
            // lblFilter
            // 
            this.lblFilter.AutoSize = true;
            this.lblFilter.Location = new System.Drawing.Point(19, 116);
            this.lblFilter.Name = "lblFilter";
            this.lblFilter.Size = new System.Drawing.Size(128, 13);
            this.lblFilter.TabIndex = 29;
            this.lblFilter.Text = "Filtrera din sökning efter...";
            // 
            // cbxProgram
            // 
            this.cbxProgram.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.cbxProgram.FormattingEnabled = true;
            this.cbxProgram.Location = new System.Drawing.Point(26, 200);
            this.cbxProgram.Name = "cbxProgram";
            this.cbxProgram.Size = new System.Drawing.Size(154, 21);
            this.cbxProgram.TabIndex = 28;
            this.cbxProgram.Text = "Program";
            // 
            // cbxSkolor
            // 
            this.cbxSkolor.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.cbxSkolor.FormattingEnabled = true;
            this.cbxSkolor.Location = new System.Drawing.Point(26, 173);
            this.cbxSkolor.Name = "cbxSkolor";
            this.cbxSkolor.Size = new System.Drawing.Size(153, 21);
            this.cbxSkolor.TabIndex = 27;
            this.cbxSkolor.Text = "Skola";
            // 
            // cbxKommuner
            // 
            this.cbxKommuner.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.cbxKommuner.FormattingEnabled = true;
            this.cbxKommuner.Location = new System.Drawing.Point(26, 146);
            this.cbxKommuner.Name = "cbxKommuner";
            this.cbxKommuner.Size = new System.Drawing.Size(121, 21);
            this.cbxKommuner.TabIndex = 26;
            this.cbxKommuner.Text = "Kommun";
            // 
            // lblPersonNr
            // 
            this.lblPersonNr.AutoSize = true;
            this.lblPersonNr.Location = new System.Drawing.Point(205, 24);
            this.lblPersonNr.Name = "lblPersonNr";
            this.lblPersonNr.Size = new System.Drawing.Size(57, 13);
            this.lblPersonNr.TabIndex = 25;
            this.lblPersonNr.Text = "Person Nr:";
            // 
            // tbxPersonNr
            // 
            this.tbxPersonNr.Location = new System.Drawing.Point(268, 21);
            this.tbxPersonNr.Name = "tbxPersonNr";
            this.tbxPersonNr.Size = new System.Drawing.Size(100, 20);
            this.tbxPersonNr.TabIndex = 24;
            // 
            // tbxMerit
            // 
            this.tbxMerit.Location = new System.Drawing.Point(80, 57);
            this.tbxMerit.Name = "tbxMerit";
            this.tbxMerit.Size = new System.Drawing.Size(100, 20);
            this.tbxMerit.TabIndex = 23;
            // 
            // lblMerit
            // 
            this.lblMerit.AutoSize = true;
            this.lblMerit.Location = new System.Drawing.Point(11, 60);
            this.lblMerit.Name = "lblMerit";
            this.lblMerit.Size = new System.Drawing.Size(63, 13);
            this.lblMerit.TabIndex = 22;
            this.lblMerit.Text = "Meritpoäng:";
            // 
            // lblNamn
            // 
            this.lblNamn.AutoSize = true;
            this.lblNamn.Location = new System.Drawing.Point(23, 24);
            this.lblNamn.Name = "lblNamn";
            this.lblNamn.Size = new System.Drawing.Size(38, 13);
            this.lblNamn.TabIndex = 21;
            this.lblNamn.Text = "Namn:";
            // 
            // rbxLista
            // 
            this.rbxLista.Location = new System.Drawing.Point(26, 227);
            this.rbxLista.Name = "rbxLista";
            this.rbxLista.Size = new System.Drawing.Size(379, 199);
            this.rbxLista.TabIndex = 20;
            this.rbxLista.Text = "";
            // 
            // tbxNamn
            // 
            this.tbxNamn.Location = new System.Drawing.Point(80, 21);
            this.tbxNamn.Name = "tbxNamn";
            this.tbxNamn.Size = new System.Drawing.Size(100, 20);
            this.tbxNamn.TabIndex = 19;
            // 
            // btnSök
            // 
            this.btnSök.Location = new System.Drawing.Point(280, 57);
            this.btnSök.Name = "btnSök";
            this.btnSök.Size = new System.Drawing.Size(75, 23);
            this.btnSök.TabIndex = 18;
            this.btnSök.Text = "Sök";
            this.btnSök.UseVisualStyleBackColor = true;
            this.btnSök.Click += new System.EventHandler(this.btnSök_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 478);
            this.Controls.Add(this.lblExempel);
            this.Controls.Add(this.btnVälj);
            this.Controls.Add(this.cbxVisaAlla);
            this.Controls.Add(this.lblFilter);
            this.Controls.Add(this.cbxProgram);
            this.Controls.Add(this.cbxSkolor);
            this.Controls.Add(this.cbxKommuner);
            this.Controls.Add(this.lblPersonNr);
            this.Controls.Add(this.tbxPersonNr);
            this.Controls.Add(this.tbxMerit);
            this.Controls.Add(this.lblMerit);
            this.Controls.Add(this.lblNamn);
            this.Controls.Add(this.rbxLista);
            this.Controls.Add(this.tbxNamn);
            this.Controls.Add(this.btnSök);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExempel;
        private System.Windows.Forms.Button btnVälj;
        private System.Windows.Forms.CheckBox cbxVisaAlla;
        private System.Windows.Forms.Label lblFilter;
        private System.Windows.Forms.ComboBox cbxProgram;
        private System.Windows.Forms.ComboBox cbxSkolor;
        private System.Windows.Forms.ComboBox cbxKommuner;
        private System.Windows.Forms.Label lblPersonNr;
        private System.Windows.Forms.TextBox tbxPersonNr;
        private System.Windows.Forms.TextBox tbxMerit;
        private System.Windows.Forms.Label lblMerit;
        private System.Windows.Forms.Label lblNamn;
        private System.Windows.Forms.RichTextBox rbxLista;
        private System.Windows.Forms.TextBox tbxNamn;
        private System.Windows.Forms.Button btnSök;

    }
}

